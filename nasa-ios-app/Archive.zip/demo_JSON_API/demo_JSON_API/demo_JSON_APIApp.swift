//
//  demo_JSON_APIApp.swift
//  demo_JSON_API
//
//  Created by Aluno ISTEC on 17/05/2023.
//

import SwiftUI

@main
struct demo_JSON_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
