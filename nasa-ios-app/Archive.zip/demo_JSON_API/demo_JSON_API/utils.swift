//
//  utils.swift
//  demo_JSON_API
//
//  Created by Aluno ISTEC on 17/05/2023.
//

import Foundation

extension Numeric {
    var asString: String {
        "\(self)"
    }
    
}
