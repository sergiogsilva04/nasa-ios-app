//
//  Post.swift
//  demo_JSON_API
//
//  Created by Aluno ISTEC on 17/05/2023.
//

import Foundation

typealias Posts = [Post]

struct Post: Identifiable, Codable {
    var userId: Int
    var id: Int
    var title: String
    var body: String
}

class loadData: ObservableObject {
    var url: URL
    
    init(url: String) {
        self.url = URL(string: url)!
    }
    
    func loadAllData(completion: @escaping (Posts) -> Void) {
        print("loadAllData início")
        
        let dataTask = URLSession.shared.dataTask(with: self.url) { myData, httpResponse, error in
            print("dataTask início")
            
            if let error {
                print("Erro: \(error.localizedDescription)")
            }
            
            guard let response = httpResponse as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("Código inválido: \((httpResponse as? HTTPURLResponse)!.statusCode)")
                    
                return
            }
            
            print("if let dados = myData antes")
            
            if let data = myData, let data = try? JSONDecoder().decode(Posts.self, from: data) {
                print("if let dados = myData inicio")
                
                // sleep(10)
                completion(data)
                
                print("if let dados = myData fim")
            }
            
            print("if let dados = myData depois")
            print("dataTask fim")
        }
        
        print("dataTask.resume() início")
        
        dataTask.resume()
        
        print("datatask.resume() fim")
        
        print("loadalldata fim")
    }
    
    func loadPostWith(id: Int, completion: @escaping (Post) -> Void) {
        self.url.append(component: id.asString)
        
        print("loadAllData início")
        
        let dataTask = URLSession.shared.dataTask(with: self.url) { myData, httpResponse, error in
            print("dataTask início")
            
            if let error {
                print("Erro: \(error.localizedDescription)")
            }
            
            guard let response = httpResponse as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("Código inválido: \((httpResponse as? HTTPURLResponse)!.statusCode)")
                    
                return
            }
            
            print("if let dados = myData antes")
            
            if let data = myData, let data = try? JSONDecoder().decode(Post.self, from: data) {
                print("if let dados = myData inicio")
                
                // sleep(10)
                completion(data)
                
                print("if let dados = myData fim")
            }
            
            print("if let dados = myData depois")
            print("dataTask fim")
        }
        
        print("dataTask.resume() início")
        
        dataTask.resume()
        
        self.url.deleteLastPathComponent()
        
        print("datatask.resume() fim")
        
        print("loadalldata fim")
    }
    
    func loadAsync() async throws -> Posts? {
        let urlRequest = URLRequest(url: self.url)
        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            fatalError("Erro no statusCode")
        }
        
        let myData = try JSONDecoder().decode(Posts.self, from: data)
        
        return myData
    }
}
