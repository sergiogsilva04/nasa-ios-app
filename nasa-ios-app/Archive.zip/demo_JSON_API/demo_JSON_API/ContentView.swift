//
//  ContentView.swift
//  demo_JSON_API
//
//  Created by Aluno ISTEC on 17/05/2023.
//

import SwiftUI

struct ContentView: View {
    @StateObject var load = loadData(url: "https://jsonplaceholder.typicode.com/posts")
    @State var loading = false
    
    var body: some View {
        VStack {
            if loading {
                ProgressView()
            }
            
            Button {
                loading = true
                print("btn inicio")
                    
                load.loadAllData { myPosts in
                    print("clouser inicio")
                    
                    print(myPosts.count)
                    
                    print("clouster fim")
                    
                    loading = false
                }
                
                print("btn fim")
            } label: {
                Text("load All data")
            }
            .disabled(loading)
            
            Button("lOAD post 1") {
                self.load.loadPostWith(id: 1) { post in
                    print(post)
                }
            }
            
            Button("Load posts async") {
                Task {
                    do {
                        var res = try await load.loadAsync()
                        print(res!.last!)
                    } catch {
                        print("Erro")
                    }
                }
            }
        }
        .task {
            do {
                var res = try await load.loadAsync()
                print(res!.last!)
            } catch {
                print("Erro")
            }
        }
        
         /*.onAppear {
            load.loadAllData { myPosts in
                print("clouser inicio")
                print(myPosts.count)
                print("clouser fim ")
                loading = false
         }*/
         
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
