//
//  toList.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import Foundation

protocol listData {
    var listaContactos: [Contacto] { get set }
}
