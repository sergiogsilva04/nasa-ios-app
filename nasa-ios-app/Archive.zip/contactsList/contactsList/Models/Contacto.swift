import Foundation

class Contacto: Identifiable {
    var id = UUID()
    var nome: String
    var telefone: Int
    private var _email: String?
    private var _foto: String?
    
    var email: String {
        get {
            self._email ?? "Sem email"
        }
        
        set {
            self._email = newValue
        }
    }
    
    var foto: String {
        get {
            self._foto ?? "noImg"
        }
        
        set {
            self._foto = newValue
        }
    }
    
    init(nome: String, telefone: Int, email: String? = nil, foto: String? = nil) {
        self.nome = nome
        self.telefone = telefone
        self._email = email
        self._foto = foto
    }
}
