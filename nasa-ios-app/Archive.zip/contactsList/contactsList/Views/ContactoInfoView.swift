//
//  ContactoInfoView.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

struct ContactoInfoView: View {
    var contacto: Contacto
    
    var body: some View {
        NavigationStack {
            VStack {
                Image(contacto.foto)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 150, height: 150)
                    .clipShape(Circle())
                
                Spacer()
                    .frame(height: 95)
                
                List {
                    Text(contacto.email)
                    Text("\(contacto.telefone)")
                }
                .listStyle(.inset)
                .scrollDisabled(true)
                .padding(.horizontal, 32)
            }
            .navigationTitle(contacto.nome)
        }
    }
}

struct ContactoInfoView_Previews: PreviewProvider {
    static var previews: some View {
        ContactoInfoView(contacto: Contacto(nome: "Maria", telefone: 222222222, foto: "foto1"))
    }
}
