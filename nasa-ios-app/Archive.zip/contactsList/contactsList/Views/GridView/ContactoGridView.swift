//
//  ContactoGridView.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

struct ContactoGridView: View {
    var viewModel: listData
    
    var body: some View {
        NavigationStack {
            LazyVGrid(columns: [
                GridItem(.fixed(150)),
                GridItem(.fixed(150)),
                GridItem(.fixed(150))
                
            ]) {
                ForEach(viewModel.listaContactos) { contacto in
                    NavigationLink {
                        ContactoInfoView(contacto: contacto)
                        
                    } label: {
                        GridCellView(contacto: contacto)
                    }
                }
            }
        }
    }
}
