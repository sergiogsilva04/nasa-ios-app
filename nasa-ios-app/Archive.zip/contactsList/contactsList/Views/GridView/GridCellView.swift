//
//  GridCellView.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

struct GridCellView: View {
    var contacto: Contacto
    
    var body: some View {
        VStack {
            Image(contacto.foto)
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
            
            Text(contacto.nome)
        }
    }
}

struct GridCellView_Previews: PreviewProvider {
    static var previews: some View {
        GridCellView(contacto: Contacto(nome: "maria", telefone: 2222222, foto: "foto1"))
    }
}
