//
//  ContentViewModel.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

class ContentViewModel: ObservableObject, listData {
    @Published var nomeTF: String = "Sem nome"
    @Published var color: Color = .blue
    @Published var lista = true
    @Published var listaContactos: [Contacto]
    
    init() {
        self.listaContactos = [
            Contacto(nome: "Joao", telefone: 111111111),
            Contacto(nome: "Maria", telefone: 222222222, foto: "foto1"),
            Contacto(nome: "Pedro", telefone: 333333333, foto: "foto2"),
            Contacto(nome: "Rita", telefone: 444444444, email: "rita@sapo.pt", foto: "foto3")
        ]
    }
    
    func changeColor(para novaCor: Color) {
        self.color = novaCor
    }
}
