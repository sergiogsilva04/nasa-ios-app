//
//  ContentView.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ContentViewModel()
    
    var body: some View {
        NavigationStack {
            VStack {
                if (viewModel.lista) {
                    ListaContactosView(viewModel: viewModel)
                    
                } else {
                    ContactoGridView(viewModel: viewModel)
                }
                
                Spacer()
                
                Toggle(isOn: self.$viewModel.lista) {
                    Text("Lista?")
                }
                .frame(width: 150)
            }
            .navigationTitle("Contactos")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Image(systemName: "plus")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
