//
//  ListItemView.swift
//  contactsList
//
//  Created by Aluno ISTEC on 10/05/2023.
//

import SwiftUI

struct ListItemView: View {
    var contacto: Contacto
    
    var body: some View {
        HStack {
            Image(contacto.foto)
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
            
            Text(contacto.nome)
                .font(.title3)
                .fontWeight(.bold)
        }
    }
}

struct ListItemView_Previews: PreviewProvider {
    static var previews: some View {
        ListItemView(contacto: Contacto(nome: "maria", telefone: 2222222, foto: "foto1"))
    }
}
