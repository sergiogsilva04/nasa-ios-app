import SwiftUI

struct ListaContactosView: View {
    var viewModel: listData
    
    var body: some View {
        NavigationStack {
            List {
                ForEach (viewModel.listaContactos) { contacto in
                    NavigationLink {
                        ContactoInfoView(contacto: contacto)
                        
                    } label: {
                        ListItemView(contacto: contacto)
                    }
                }
            }
        }
    }
}
