import SwiftUI

@main
struct contactsListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
